#!/usr/bin/env python3
import certilib

if __name__ == '__main__':
    certilib.main()
